# 🎨 Battle Doodle (Prototype)

Multiplayer drawing + guessing game (prototype).

## Features
- Real-time drawing sync (Firebase)
- Voice chat support (PeerJS / WebRTC)
- Direct link join, no login

## How to Run
1. Upload this folder to your GitHub repository.
2. Enable GitHub Pages.
3. Add your Firebase project config in `script.js`.
4. Share the link with friends, start playing!
