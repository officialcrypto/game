// Firebase config placeholder (add your firebase project info)
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  databaseURL: "https://YOUR_PROJECT_ID.firebaseio.com",
  projectId: "YOUR_PROJECT_ID",
};
firebase.initializeApp(firebaseConfig);
const db = firebase.database();

// Simple canvas drawing
const canvas = document.getElementById("gameCanvas");
canvas.width = 600;
canvas.height = 400;
const ctx = canvas.getContext("2d");

let drawing = false;
canvas.addEventListener("mousedown", () => drawing = true);
canvas.addEventListener("mouseup", () => drawing = false);
canvas.addEventListener("mousemove", draw);

function draw(e) {
  if (!drawing) return;
  ctx.fillStyle = "black";
  ctx.fillRect(e.offsetX, e.offsetY, 2, 2);
  // Save stroke in firebase
  const stroke = { x: e.offsetX, y: e.offsetY };
  db.ref("strokes").push(stroke);
}

// Listen for strokes from other players
db.ref("strokes").on("child_added", (snapshot) => {
  const {x, y} = snapshot.val();
  ctx.fillStyle = "red";
  ctx.fillRect(x, y, 2, 2);
});

// PeerJS (voice chat prototype)
const peer = new Peer();
peer.on('open', id => {
  console.log("My Peer ID:", id);
});
